def main():
    # Main function to run the application
    app = MainMenu()
    app.mainloop()

if __name__ == "__main__":
    main()
